$(document).ready(function(){
    $(".submit").click(function(){
        var fn = $("#fn").val();
        var ln = $("#ln").val();
        var description = $("#description").val();
        $(".anything").append("<div class='info'>"+ "<br>" + "<br>" + "<p><b>" + fn + " " + ln + "</b></p>" + "<p>Click for description</p><h5 class='hide'>"+description+"</h5></div>");
        return false;
    })
    $(document).on('click', ".info", function(){
        if ($(this).children("h5").hasClass("hide")){
            $(this).children("h5").removeClass("hide");
            $(this).children("p").addClass("hide");
        }
        else {
            $(this).children("h5").addClass("hide");
            $(this).children("p").removeClass("hide");

        }
    });

})



// $(document).ready(function(){
//     $(".submit").click(function(){
//         var fn = $("#fn").val();
//         var ln = $("#ln").val();
//         $(".anything").append("<div>"+ "<br>" + "<br>" + "<b>" + fn + " " + ln + "</b>"+"<br>" + "<br>" + "<br>" + "<br>" + "Click for description"+"</div>");
//         return false;
//     })
//     $(document).on('click', ".anything div", function(){
//         var description = $("#description").val();
//         $(this).replaceWith("<div>"+"<br>" + "<br>"+"<br>" + "<br>" +description+"</div>");
//     });
//
// })
